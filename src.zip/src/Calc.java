public interface Calc {
    public void sum(double... nums);
}
