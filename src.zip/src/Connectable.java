public interface Connectable {
    public void addConnection(City destination, int cost);
    public void addConnections(City destination, int cost);
}
