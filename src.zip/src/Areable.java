public interface Areable {
    double area();
}