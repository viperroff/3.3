public interface Lengthable {
    public double getLength();
}
