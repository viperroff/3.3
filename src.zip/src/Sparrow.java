public class Sparrow implements Singable{

    public void sing(){
        System.out.println("чырык");
    }
}
