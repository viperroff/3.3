import java.util.List;
public interface Addable {
    public List<Point> getPolyline();
}
