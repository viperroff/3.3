abstract class Figure implements Areable{
    private Point center;
}
