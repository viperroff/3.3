public interface Shootable {
    public void shoot();
}
