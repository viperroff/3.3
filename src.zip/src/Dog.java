public class Dog {

}
