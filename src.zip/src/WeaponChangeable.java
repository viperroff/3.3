public interface WeaponChangeable {
    public void changeWeapon(Weapon weapon);
}
