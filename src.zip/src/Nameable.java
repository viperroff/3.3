public interface Nameable {
    public void SetName(String name);
}
