public class Cat implements Meowable{
    public void meow(){
        System.out.println("Мяу!");
    }
}
