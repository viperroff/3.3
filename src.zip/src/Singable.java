public interface Singable {
    public void sing();
}